module WorkRateCalculator {
}