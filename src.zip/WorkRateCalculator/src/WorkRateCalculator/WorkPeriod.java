package WorkRateCalculator;

public class WorkPeriod {
	//WorkPeriod represents a period of time during which the pay rate is constant
	public static final int EARLIEST_START_TIME = 5;
	public static final int LATEST_END_TIME = 4;
	public static final String WORK_DAY_HOURS_HELP= "Work day hours (5pm - 4am)";
	public static final String START_TIME = "start";
	public static final String END_TIME = "end";
	
	private String name = null;
	private Integer start = null; 
		//start cannot be equal to or later than end time
		//if end time is null, then start is compared to max to ensure is does not go beyond allowed period
	private Integer end = null;
		//end cannot be equal to or earlier than start time
		//if start time is null, then start is compared to min to ensure is does not go beyond allowed period
	private Integer max = null; //the latest time that this work period can end
	private Integer min = null; //the earliest that this work time can start
	private Integer payRate = null; //pay rate for this time period 
	//time is represented as Integer values because times are consider to be 'on the hour' values	
	
	public WorkPeriod(String name) {
	//constructer with named name
		setName(name);
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getStart() {
		return start;
	}
	
	public void setStart(Integer start) throws Exception {
		String validError = this.validateTime(START_TIME, start);
		//make sure time is inside valid bounds of time period
		if (validError==null)
		{
			this.start = start;
		} else {
			throw new Exception(validError);
		}
	}
	
	public Integer getEnd() {
		return end;
	}
	
	public void setEnd(Integer end) throws Exception {
		String validError = this.validateTime(END_TIME, end);
		//make sure time is inside valid bounds of time period

		if (validError==null)
		{
			this.end = end;
		} else {
			throw new Exception(validError);
		}
	}
	
	public Integer getMax() {
		return max;
	}
	public void setMax(Integer max) {
	//we can only set this once
		if (this.max==null) {
			this.max = max;
		}
	}
	public Integer getMin() {
		return min;
	}
	public void setMin(Integer min) {
	// this can only be set once
		if (this.min==null) {
			this.min = min;
		}
	}
	public int getShiftLengthHours() throws NullPointerException {
	//get number of hours between start and end times
		if (this.end==null || this.start==null)
		{
			throw new NullPointerException("A start and end time need to be set to determine shift length");
		} else {
		//time between start and end
			return this.end - this.start;
		}
	}
	
	public Integer getPayRate() {
		return payRate;
	}

	public void setPayRate(Integer payRate) {
		this.payRate = payRate;
	}

	public int periodPay() throws NullPointerException{
	//pay for this period is time worked multipled by pay rate
		if (this.start!=null && this.end!=null && this.payRate!=null)
		{
			return diff(this.start,this.end) * payRate;
		} 
		else 
		{
			throw new NullPointerException("To calculate pay for this period, you need a start date, end date and a pay rate");
		}
	}

	private static Integer diff(Integer Time1, Integer Time2) throws NullPointerException {
		//hours between 5pm and 4am (next morning)
		//Time1 is earlier time and Time2 is later time, or else negative number will be returned
		if (Time1==null || Time2==null)
		{
			throw new NullPointerException("Diff times cannot be null");
		}
		
		Time1 = normalize(Time1); 
		Time2 = normalize(Time2);
		
		return Time2 - Time1;
	}
	
	private static Integer normalize(Integer n) {
		//we need to adjust times so for instance "1am" is not counted as 1 when compared to 12
		//this will lead to 1am being "less than" midnight
		if (n<=LATEST_END_TIME) {
			//convert 1-4 o'clock to 13-16 so they register as later than 8-12pm
			n += 12;
		}	
		
		return n;
	}
	
	private static boolean isLater(Integer Time1, Integer Time2) {
		//treat null as "beginning of time" i.e. time=0 - i.e NOTHING is later than null
		if (Time1==null)
		{
			return false;
		}
		else {
			if (Time2==null)
			{
				return true;
			}
			else
			{
				return (WorkPeriod.diff(Time1, Time2)<0);
				//if the difference is negative, then Time1 is earlier that Time2
				//if it is zero, Times are the same and hence NOT later
			}
		}
	}
	
	public String validateTime(String type, Integer time)
	{
		//check times are withing bounds of allowed time in period
		//time type is either START_TIME or END_TIME
		String returnVal = null;
		if (!isValidTime(time)) 
		{
			//do a basic check to see if the time entered is a valid chronological hour
			returnVal = "This is not a valid time value "+WORK_DAY_HOURS_HELP;
		}
				
		if (returnVal==null) {
			if (type.equals(START_TIME)) {
				///time has got to be between earliest time for shift(min)
				///and end time (if not null) OR latest allowed time for shift(max)
				if (this.end!=null) {
					if (!WorkPeriod.isLater(this.end,time)) {
					//new start time cannot be after the end time
						returnVal = "Pay period start cannot occur after or at the same time as end"
									+ "(End: " + this.end + ")";
					} else if (WorkPeriod.isLater(this.min, time)) {
					//new start time cannot be earlier than min time
						returnVal = "Time cannot occur beyond minimum bounds of time period";
						if (this.min!=null) returnVal += "(Minimum:"+this.min+")";		
					} 
				} else {
					if (!WorkPeriod.isLater(this.max,time)) {
					//time cannot be after the max time
						returnVal = "Start time cannot occur after or equal to the latest time allowed for this period";
						if (this.max!=null) returnVal += "(Maximum:"+this.max+")";		
					}
				}
			} else if (type.equals(END_TIME)) {
				//time has got to be between start time (if not null) OR min time and latest time allowed (max)
				if (this.start!=null) {
					if (!WorkPeriod.isLater(time,this.start)) {
					//new end time cannot be earlier than start time
						returnVal = "Pay period end cannot occur before or at the same time as the start of this period"
								    +"(Start: "+this.start+")";
					} else if (WorkPeriod.isLater(time, this.max)) {
					//new end time cannot be later than the max allowed time
						returnVal = "Time cannot occur beyond maximum bounds of time period";
						if (this.max!=null) returnVal += "(Maximum:"+this.max+")";		
					} 
				} else {
				//no start time yet, validate against minimum time	
					if (WorkPeriod.isLater(time,this.min)) {
						returnVal = "End time cannot occur before or equal to the earliest time allowed for this period";
						if (this.max!=null) returnVal += "(Minimum:"+this.min+")";		
					}
				}
					
			}
		}
		return returnVal;
	}
		
	public static boolean isValidTime(Integer time) {
		return (time>0 && time<13);
	}
	
	public String toString() {
	//turn object into a legible string containing object values
		return (String.join("\n", "Period: "+this.getName(),
				"Start Time: "+this.getStart(),
				"End Time: "+this.getEnd(),
				"Pay: $"+this.periodPay())
		);
	}
			   
	public String getInfo( ) {
	//user info about the period
		String returnVal = "";
		
		returnVal = "Pay period: "+ this.getName() + "\n"
					+ "Should start and end between " + this.getMin()
					+ " and " + this.getMax() + "\n";
		
		return returnVal;
	}
}