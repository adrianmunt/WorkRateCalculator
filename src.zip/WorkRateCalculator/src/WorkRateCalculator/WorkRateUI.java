package WorkRateCalculator;

public interface WorkRateUI {
	//This interface object represents the output methods required for a UI for this application

	public void putHeader(String header);
		//output header text (title, information etc) that user will consume before inputting the required values
	public int getTime(String getString);
		//get input from user regarding time value
	public void putTime(String putString);
		//output a time value
	public void putError(String errorString);
	    //output an error in the script
	public void putConclusion(String errorString);
		//output final information (such as final total) or end salutation
	public void put(String info);
		//output other information that is not covered by other functions
	
	
}
