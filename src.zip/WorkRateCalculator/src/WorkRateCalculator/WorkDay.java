package WorkRateCalculator;

import java.util.LinkedList;

public class WorkDay extends LinkedList<WorkPeriod>{
//WorkDay encapsulate a 'Day' consisting of a consecutive list of 'work periods' with each work period
//characterized by a period of time work earning a certain pay rate
	public Integer totalPay() throws NullPointerException {
		//Total up the pay across all work periods and return an Integer representing dollars earned that day
		Integer total = 0;
		
		try {
			for (WorkPeriod w : this)
			{
				total += w.periodPay();
			}
			
		} catch (Exception e) {
			throw(e);
		}
		return total;	
	}
	
	public String toString() {
		//turn the object into a legible string of object values
		String returnVal = "";
		
		for (WorkPeriod w : this)
		{
			returnVal += "\n";
			returnVal += w.toString() + "\n";
		}
		return returnVal;
	}
}
