package WorkRateCalculator;

import java.util.Scanner;

public class WorkRateCalculator {

	public static void main(String[] args) {		
		final int MIDNIGHT = 12;
		final int EARLIEST_BED_TIME = WorkPeriod.EARLIEST_START_TIME + 1;
		final int LATEST_BED_TIME = MIDNIGHT - 1;
		
		final int PLAY_PAY_RATE = 12;
		final int BEDTIME_PAY_RATE = 8;
		final int MIDNIGHT_PAY_RATE = 16;		
		//these constant values should be in a configuration file
		//typically values that are subject to being changed are placed in a config file
		//to ensure that as many changes as possible can be handled without changing code

		SimpleWorkRateUI ui = new SimpleWorkRateUI();
		 //Simple text UI - here will be an opportunitry to define ui as a different type of user interface (web page, phone app, file, etc)
		try {
			//"Work Day" consists of a number of work periods
			//For the purposes of this program a Work Day consists of 3 periods:
			//	Play Period - a time that is one hour or greater determined to be time between start of work and bedtime for child
			//  Bedtime - a time that is one hour or greater determined to be time between bedtime and midnight
			//  Midnight - a time that is one hour or greater determined to be time between midnight and the end of work
			WorkDay myDay = new WorkDay();
			ui.putHeader("Welcome to the Work Rate Calculator for Babysitting.\n"
						 +WorkPeriod.WORK_DAY_HOURS_HELP+"\n");
			
			WorkPeriod play = new WorkPeriod("Play Period");
			play.setMin(WorkPeriod.EARLIEST_START_TIME);
			play.setPayRate(PLAY_PAY_RATE);
			play.setMax(LATEST_BED_TIME);
			
			String error;
			do {
				Integer nstartt = ui.getTime(play.getInfo()+"\nPlease enter START time:");
				error = play.validateTime(WorkPeriod.START_TIME, nstartt); 
				if (error!=null) {
					ui.putError(error);
				} else {
					play.setStart(nstartt);
				}
			} while (error!=null);
			//Get the start time, loop until a valid time is received

			WorkPeriod bedtime = new WorkPeriod("Sleep Time (before midnight)");
			bedtime.setMax(MIDNIGHT);
			bedtime.setMin(EARLIEST_BED_TIME);
			bedtime.setPayRate(BEDTIME_PAY_RATE);
			
			do {
				Integer nendt = ui.getTime(bedtime.getInfo()+"\nPlease enter BEDTIME:");
				error = play.validateTime(WorkPeriod.END_TIME, nendt); 
				if (error!=null) {
					ui.putError(error);
				} else {
					play.setEnd(nendt);
				}
			} while (error!=null);
			//Get bedtime
			
			myDay.add(play);
			//add play period to the day's events
			
			bedtime.setStart(play.getEnd());
			//'bedtime' is both the end of 'play time' and the start of the bedtime period
			bedtime.setEnd(MIDNIGHT);		
			myDay.add(bedtime);
			//add bedtime to day's events
			
			WorkPeriod midnight = new WorkPeriod("After Midnight");
			midnight.setMax(WorkPeriod.LATEST_END_TIME);
			midnight.setMin(MIDNIGHT);
			midnight.setPayRate(MIDNIGHT_PAY_RATE);
			midnight.setStart(MIDNIGHT);
			
			do {
				Integer mendt = ui.getTime(midnight.getInfo()+"\nPlease enter evening END time:");
				error = midnight.validateTime(WorkPeriod.END_TIME,mendt); 
				if (error!=null) {
					ui.putError(error);
				} else {
					midnight.setEnd(mendt);
				}
			} while (error!=null);
			
			myDay.add(midnight);
			ui.put(myDay.toString());

			ui.putConclusion("Total pay for the day is $"+myDay.totalPay()+"\n\n");
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

}

class SimpleWorkRateUI implements WorkRateUI{
//implementation if a simple UI for this app	
	public int getTime(String getString) {
		Scanner sc = new Scanner(System.in);
		Integer inputVal;
		do {
			System.out.println(getString + "[0 to exit]");
			try {
				inputVal = Integer.parseInt(sc.nextLine());
			} catch (Exception e) {
				System.out.println("Value needs to be a numeric decimal representing the hour");
				inputVal = null;
			}
		} while (inputVal==null);
		//sc.close(); //closure of this invalidates any input, need to investigate
		if (inputVal==0) System.exit(0);
		//provide an out to any program (enter 0 for quitting)
		return inputVal.intValue();
	}
//NOTE: these methods are all the same, but this is not necessarily true for other UI types (e.g. web output could put errors in red, etc.)	
	public void putTime(String putString) {
		System.out.println(putString);
	}
	
	public void putHeader(String putHeader) {
		System.out.println(putHeader);
	}

	public void putError(String putError) {
		System.out.println(putError);
	}

	public void putConclusion(String putConclusion) {
		System.out.println(putConclusion);
	}
	
	public void put(String info) {
		System.out.println(info);
	}
}
